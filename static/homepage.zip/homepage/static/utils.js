(function (w,d){

    function $id(id) {
        return d.getElementById(id);
    }
    function $(selector) {
        return d.querySelector(selector);
    }
    function $_(selector) {
        return d.querySelectorAll(selector);
    }
    function $ajax(args) {
        // args:
        // {
        // url:'URL',
        // method: 'GET/POST',
        // success: function
        // }

        var request = new XMLHttpRequest();
        request.open(method= args.method,url= args.url,true);
        request.onreadystatechange = function(){
            if (request.readyState === 4 && request.status === 200){
                args.success(request);
            }
        };
        request.send()
    }

    w['$id']=$id;
    w['$']=$;
    w['$_']=$_;
    w['$ajax'] = $ajax;

})(window,document);